﻿using System;

namespace SW2URDF.UI
{
    public class TreeModifiedEventArgs : EventArgs
    {
        public URDFTreeView Tree;
    }
}